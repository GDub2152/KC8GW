# KC8GW Operations Center 6.0.1 Production

Single-project production build for the KC8GW AllStar/EchoLink station.

## Production endpoints
- Operations Center: `http://<node>:8110/`
- Backend: `127.0.0.1:8798`
- Allmon3: `/allmon3/` through the same Nginx site

## Data
Persistent data remains under `/mnt/kc8gw-data`.

## Important production changes
- One web service and one station monitor.
- Browser status requests use the monitor cache rather than repeatedly polling Asterisk.
- Full diagnostics/SMART checks run at a slower cadence.
- V6 owns its own audio-index and backup timers.
- Log/restart actions target V6 services, not retired v5.x services.
- Upgrade backs up the current V6 and automatically restores it if health checks fail.

## Install/update
`sudo bash install-v6-production.sh`

## Verify
`sudo bash scripts/healthcheck.sh`

## Old preview cleanup
Run `sudo bash cleanup-old-previews.sh --dry-run` first. Only use `--apply` after V6 is verified.
