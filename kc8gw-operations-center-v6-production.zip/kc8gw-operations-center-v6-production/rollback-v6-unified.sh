#!/usr/bin/env bash
set -euo pipefail
DATA=/mnt/kc8gw-data
TARGET=/opt/kc8gw-operations-v6
UNIT_WEB=/etc/systemd/system/kc8gw-operations-v6.service
UNIT_MON=/etc/systemd/system/kc8gw-v6-monitor.service
NG_AV=/etc/nginx/sites-available/kc8gw-operations-v6
if [[ -f "$TARGET/ROLLBACK_PATH" ]]; then SAFE=$(cat "$TARGET/ROLLBACK_PATH");
elif [[ -f "$DATA/operations/v6/last-unified-backup-path" ]]; then SAFE=$(cat "$DATA/operations/v6/last-unified-backup-path");
else echo "No unified V6 rollback path found."; exit 1; fi
[[ -d "$SAFE" ]] || { echo "Backup not found: $SAFE"; exit 1; }
echo "Restoring V6 from $SAFE"
systemctl stop kc8gw-operations-v6.service kc8gw-v6-monitor.service 2>/dev/null || true
rm -rf "$TARGET"
[[ -d "$SAFE/current-v6" ]] && cp -a "$SAFE/current-v6" "$TARGET"
[[ -e "$SAFE/kc8gw-operations-v6.service" ]] && cp -a "$SAFE/kc8gw-operations-v6.service" "$UNIT_WEB"
[[ -e "$SAFE/kc8gw-v6-monitor.service" ]] && cp -a "$SAFE/kc8gw-v6-monitor.service" "$UNIT_MON"
[[ -e "$SAFE/kc8gw-operations-v6" ]] && cp -a "$SAFE/kc8gw-operations-v6" "$NG_AV"
ln -sfn "$NG_AV" /etc/nginx/sites-enabled/kc8gw-operations-v6
systemctl daemon-reload
nginx -t
systemctl restart kc8gw-v6-monitor.service kc8gw-operations-v6.service
systemctl reload nginx
echo "Previous V6 restored."
