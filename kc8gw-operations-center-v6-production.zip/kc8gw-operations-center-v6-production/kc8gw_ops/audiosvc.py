from __future__ import annotations
import urllib.parse, wave, contextlib
from datetime import datetime
from pathlib import Path
from .paths import ARCHIVE_DIR
from .db import connect
ALLOWED={'.wav','.WAV'}
def _duration(p:Path):
    try:
        with contextlib.closing(wave.open(str(p),'rb')) as w:
            rate=w.getframerate(); return round(w.getnframes()/rate,2) if rate else None
    except Exception:return None
def scan(limit=500):
    ARCHIVE_DIR.mkdir(parents=True,exist_ok=True)
    found=[]
    for p in ARCHIVE_DIR.rglob('*'):
        if not p.is_file() or p.suffix not in ALLOWED:continue
        st=p.stat(); rel=p.relative_to(ARCHIVE_DIR).as_posix(); ts=datetime.fromtimestamp(st.st_mtime).isoformat(timespec='seconds')
        found.append((st.st_mtime,rel,ts,st.st_size,_duration(p)))
    found.sort(reverse=True)
    with connect() as c:
        for _,rel,ts,size,duration in found[:limit]:
            c.execute('insert into audio_clips(path,ts,size,duration) values(?,?,?,?) on conflict(path) do update set ts=excluded.ts,size=excluded.size,duration=coalesce(excluded.duration,audio_clips.duration)',(rel,ts,size,duration))
    return clips(limit=80)
def clips(limit=80,q='',source=''):
    sql='select path,ts,size,duration,source from audio_clips where 1=1'; args=[]
    if q:
        sql+=' and lower(path) like ?'; args.append('%'+q.lower()+'%')
    if source:
        sql+=' and source=?'; args.append(source)
    sql+=' order by ts desc limit ?'; args.append(max(1,min(limit,500)))
    with connect() as c:rows=c.execute(sql,args).fetchall()
    return [dict(r)|{'name':Path(r['path']).name,'url':'/api/audio/file/'+urllib.parse.quote(r['path'],safe='/'),'download':'/api/audio/download/'+urllib.parse.quote(r['path'],safe='/')} for r in rows]
def resolve_clip(rel):
    root=ARCHIVE_DIR.resolve(); p=(ARCHIVE_DIR/rel).resolve()
    if root not in p.parents or not p.is_file() or p.suffix.lower()!='.wav':return None
    return p
