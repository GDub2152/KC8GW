from __future__ import annotations
import os,re
from .system import run,active

def collect():
    code,ipout=run(['/usr/bin/tailscale','ip','-4'],4)
    tailscale_ip=(ipout.splitlines()[0].strip() if code==0 and ipout.strip() else '')
    scode,sout=run(['/usr/bin/ss','-tln'],4)
    listeners=[]
    if scode==0:
        for line in sout.splitlines():
            m=re.search(r':(\d+)\s',line)
            if m and int(m.group(1)) in {8095,8096,8097,8098,8099,8100,8101,8102,8103,8104,8107}:
                listeners.append(int(m.group(1)))
    return {
        'tailscale':active('tailscaled'),
        'tailscale_ip':tailscale_ip,
        'preview_port':8107,
        'listeners':sorted(set(listeners)),
        'auth_enabled':bool(os.getenv('KC8GW_DASH_PASSWORD','')),
        'public_status_enabled':os.getenv('KC8GW_PUBLIC_STATUS','0').lower() in {'1','true','yes','on'},
    }
