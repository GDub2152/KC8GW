from __future__ import annotations
import os,time,sqlite3
from datetime import datetime,timedelta
from pathlib import Path
from .paths import ARCHIVE_DIR,BACKUP_ROOT,DB_PATH,DATA_ROOT
from . import db
from .backupsvc import rotate
from .audiosvc import scan

DEFAULTS={
    'audio_retention_days':90,
    'timeline_retention_days':180,
    'daily_backups_keep':30,
    'weekly_backups_keep':12,
    'monthly_backups_keep':12,
    'warn_free_percent':10,
}

def settings():
    out={}
    for k,v in DEFAULTS.items(): out[k]=db.setting('maintenance.'+k,v)
    return out

def save_settings(payload):
    clean={}
    ranges={
      'audio_retention_days':(1,3650),'timeline_retention_days':(7,3650),
      'daily_backups_keep':(1,365),'weekly_backups_keep':(1,104),'monthly_backups_keep':(1,120),
      'warn_free_percent':(1,50),
    }
    for k,(lo,hi) in ranges.items():
        try:v=int(payload.get(k,DEFAULTS[k]))
        except Exception: raise ValueError(f'Invalid value for {k}.')
        if not lo<=v<=hi: raise ValueError(f'{k} must be between {lo} and {hi}.')
        clean[k]=v; db.set_setting('maintenance.'+k,v)
    db.add_event('maintenance','Retention settings updated',str(clean))
    return clean

def _files_older_than(root:Path,days:int,pattern='*'):
    cutoff=time.time()-days*86400; rows=[]
    if not root.exists(): return rows
    for p in root.rglob(pattern):
        try:
            if p.is_file() and p.stat().st_mtime<cutoff: rows.append(p)
        except OSError: pass
    return rows

def preview():
    s=settings(); aud=_files_older_than(ARCHIVE_DIR,s['audio_retention_days'],'*.wav')
    aud_size=sum((p.stat().st_size for p in aud if p.exists()),0)
    with db.connect() as c:
        cutoff=(datetime.now()-timedelta(days=s['timeline_retention_days'])).isoformat(timespec='seconds')
        timeline_old=c.execute('select count(*) n from timeline where ts < ?',(cutoff,)).fetchone()['n']
        clip_rows=c.execute('select count(*) n from audio_clips').fetchone()['n']
    counts={}
    for kind in ('daily','weekly','monthly','manual','pre-restore'):
        d=BACKUP_ROOT/kind; counts[kind]=len(list(d.glob('*.tar.gz'))) if d.exists() else 0
    return {'settings':s,'audio_delete_count':len(aud),'audio_delete_bytes':aud_size,'timeline_delete_count':timeline_old,'indexed_clips':clip_rows,'backup_counts':counts}

def cleanup():
    s=settings(); before=preview(); deleted=0; freed=0
    for p in _files_older_than(ARCHIVE_DIR,s['audio_retention_days'],'*.wav'):
        try: freed+=p.stat().st_size; p.unlink(); deleted+=1
        except OSError: pass
    with db.connect() as c:
        cutoff=(datetime.now()-timedelta(days=s['timeline_retention_days'])).isoformat(timespec='seconds')
        c.execute('delete from timeline where ts < ?',(cutoff,))
        # Remove index rows whose files no longer exist.
        rows=c.execute('select path from audio_clips').fetchall()
        for r in rows:
            if not (ARCHIVE_DIR/r['path']).exists(): c.execute('delete from audio_clips where path=?',(r['path'],))
    rotate('daily',s['daily_backups_keep']); rotate('weekly',s['weekly_backups_keep']); rotate('monthly',s['monthly_backups_keep'])
    db.add_event('maintenance','Cleanup complete',f'{deleted} audio files • {freed} bytes freed')
    return {'deleted_audio':deleted,'freed_bytes':freed,'preview_before':before}

def reindex():
    result=scan(5000); db.add_event('maintenance','Audio index refreshed',f'{len(result)} recent clips returned'); return len(result)

def vacuum():
    with db.connect() as c: c.execute('VACUUM')
    db.add_event('maintenance','SQLite VACUUM complete',str(DB_PATH))
    return DB_PATH.stat().st_size if DB_PATH.exists() else 0

def storage_summary():
    st=os.statvfs(DATA_ROOT); total=st.f_blocks*st.f_frsize; free=st.f_bavail*st.f_frsize
    return {'total':total,'free':free,'used':total-free,'free_percent':(free/total*100) if total else 0}
