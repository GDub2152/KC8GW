from __future__ import annotations
import sqlite3, json
from datetime import datetime
from .paths import DB_PATH
SCHEMA="""
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS timeline(id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, category TEXT NOT NULL, event TEXT NOT NULL, detail TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS favorites(node TEXT PRIMARY KEY, label TEXT NOT NULL, sort_order INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS audio_clips(path TEXT PRIMARY KEY, ts TEXT NOT NULL, size INTEGER NOT NULL, duration REAL DEFAULT NULL, source TEXT DEFAULT 'mixed');
CREATE TABLE IF NOT EXISTS backups(id TEXT PRIMARY KEY, ts TEXT NOT NULL, kind TEXT NOT NULL, path TEXT NOT NULL, size INTEGER NOT NULL DEFAULT 0, verified INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS alerts_current(key TEXT PRIMARY KEY, severity TEXT NOT NULL, title TEXT NOT NULL, detail TEXT DEFAULT '', opened_ts TEXT NOT NULL, updated_ts TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS alert_history(id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, key TEXT NOT NULL, severity TEXT NOT NULL, event TEXT NOT NULL, title TEXT NOT NULL, detail TEXT DEFAULT '');
"""
def connect():
    DB_PATH.parent.mkdir(parents=True,exist_ok=True)
    c=sqlite3.connect(DB_PATH,timeout=15); c.row_factory=sqlite3.Row; return c
def init_db():
    with connect() as c:
        c.executescript(SCHEMA)
        if not c.execute('select 1 from favorites limit 1').fetchone():
            c.execute('insert or ignore into favorites(node,label,sort_order) values(?,?,?)',('2002','Parrot',0))
def add_event(category,event,detail=''):
    with connect() as c: c.execute('insert into timeline(ts,category,event,detail) values(?,?,?,?)',(datetime.now().isoformat(timespec='seconds'),category,event,detail[:500]))
def timeline(limit=80):
    with connect() as c: return [dict(r) for r in c.execute('select * from timeline order by id desc limit ?', (max(1,min(limit,500)),))]
def favorites():
    with connect() as c: return [dict(r) for r in c.execute('select node,label,sort_order from favorites order by sort_order,label')]
def save_favorites(items):
    clean=[]; seen=set()
    for i,item in enumerate(items[:40]):
        node=str((item or {}).get('node','')).strip(); label=str((item or {}).get('label','')).strip()[:48]
        if node.isdigit() and node not in seen:
            seen.add(node); clean.append((node,label or node,i))
    with connect() as c:
        c.execute('delete from favorites'); c.executemany('insert into favorites(node,label,sort_order) values(?,?,?)',clean)
    return favorites()
def setting(key,default=None):
    with connect() as c:
        r=c.execute('select value from settings where key=?',(key,)).fetchone()
        if not r:return default
        try:return json.loads(r['value'])
        except Exception:return r['value']
def set_setting(key,value):
    raw=json.dumps(value)
    with connect() as c: c.execute('insert into settings(key,value) values(?,?) on conflict(key) do update set value=excluded.value',(key,raw))
