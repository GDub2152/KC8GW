from __future__ import annotations
import tarfile, shutil, tempfile
from pathlib import Path
from datetime import datetime
from .paths import BACKUP_ROOT,DB_PATH,ENV_FILE,RPT_CONF,USBRADIO_CONF,ECHOLINK_CONF,APP_STATE
from .db import connect,add_event
from .system import run,asterisk
FILES=[RPT_CONF,USBRADIO_CONF,ECHOLINK_CONF,ENV_FILE,DB_PATH]
RESTORABLE={
    'etc/asterisk/rpt.conf': RPT_CONF,
    'etc/asterisk/usbradio.conf': USBRADIO_CONF,
    'etc/asterisk/echolink.conf': ECHOLINK_CONF,
}
def create(kind='manual'):
    stamp=datetime.now().strftime('%Y%m%d-%H%M%S'); dest=BACKUP_ROOT/kind; dest.mkdir(parents=True,exist_ok=True); archive=dest/f'kc8gw-{kind}-{stamp}.tar.gz'
    with tarfile.open(archive,'w:gz') as tf:
        for p in FILES:
            if p.exists():tf.add(p,arcname=str(p).lstrip('/'))
        if APP_STATE.exists():tf.add(APP_STATE,arcname=str(APP_STATE).lstrip('/'))
    size=archive.stat().st_size
    with connect() as c:c.execute('insert or replace into backups(id,ts,kind,path,size,verified) values(?,?,?,?,?,1)',(archive.name,datetime.now().isoformat(timespec='seconds'),kind,str(archive),size))
    add_event('backup','Backup complete',f'{kind}: {archive.name}')
    return archive
def list_backups(limit=100):
    with connect() as c:return [dict(r) for r in c.execute('select * from backups order by ts desc limit ?',(limit,))]
def rotate(kind,keep):
    d=BACKUP_ROOT/kind
    if not d.exists():return
    files=sorted(d.glob('*.tar.gz'),key=lambda p:p.stat().st_mtime,reverse=True)
    for p in files[keep:]:
        try:p.unlink()
        except Exception:pass
def scheduled():
    from .db import setting
    now=datetime.now()
    daily=int(setting('maintenance.daily_backups_keep',30)); weekly=int(setting('maintenance.weekly_backups_keep',12)); monthly=int(setting('maintenance.monthly_backups_keep',12))
    create('daily'); rotate('daily',daily)
    if now.weekday()==6:create('weekly'); rotate('weekly',weekly)
    if now.day==1:create('monthly'); rotate('monthly',monthly)
def _find_backup(backup_id:str)->Path:
    backup_id=Path(str(backup_id)).name
    with connect() as c:
        row=c.execute('select path from backups where id=?',(backup_id,)).fetchone()
    if not row: raise ValueError('Backup not found in catalog.')
    p=Path(row['path']).resolve()
    root=BACKUP_ROOT.resolve()
    if root not in p.parents or not p.is_file(): raise ValueError('Backup path is invalid.')
    return p
def restore_asterisk_configs(backup_id:str,node='58506'):
    archive=_find_backup(backup_id)
    safety=create('pre-restore')
    old={p:p.read_bytes() if p.exists() else None for p in RESTORABLE.values()}
    restored=[]
    try:
        with tarfile.open(archive,'r:gz') as tf:
            names=set(tf.getnames())
            for arc,target in RESTORABLE.items():
                if arc not in names: continue
                member=tf.getmember(arc)
                if not member.isfile(): continue
                f=tf.extractfile(member)
                if f is None: continue
                data=f.read()
                tmp=target.with_suffix(target.suffix+'.v6tmp')
                tmp.write_bytes(data)
                tmp.replace(target)
                restored.append(target.name)
        if not restored: raise RuntimeError('Selected backup contains no restorable Asterisk configuration files.')
        code,out=run(['/usr/bin/systemctl','restart','asterisk'],25)
        if code!=0: raise RuntimeError(out or 'Asterisk restart failed.')
        code,out=asterisk(f'rpt stats {node}',timeout=12)
        if code!=0 or 'STATISTICS' not in out.upper(): raise RuntimeError('Node verification failed after restore.')
        add_event('backup','Restore verified',f'{archive.name}: {", ".join(restored)}')
        return {'backup':archive.name,'safety_backup':safety.name,'restored':restored}
    except Exception:
        for p,data in old.items():
            try:
                if data is None:
                    if p.exists(): p.unlink()
                else:p.write_bytes(data)
            except Exception:pass
        run(['/usr/bin/systemctl','restart','asterisk'],25)
        add_event('backup','Restore rolled back',archive.name)
        raise
