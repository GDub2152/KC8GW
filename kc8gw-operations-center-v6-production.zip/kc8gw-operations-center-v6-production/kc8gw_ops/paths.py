from pathlib import Path
import os
DATA_ROOT=Path(os.getenv('KC8GW_DATA_ROOT','/mnt/kc8gw-data'))
DB_PATH=Path(os.getenv('KC8GW_DB',str(DATA_ROOT/'database/kc8gw_ops.db')))
ARCHIVE_DIR=Path(os.getenv('KC8GW_ARCHIVE_DIR',str(DATA_ROOT/'audio/archive')))
BACKUP_ROOT=Path(os.getenv('KC8GW_BACKUP_ROOT',str(DATA_ROOT/'backups')))
APP_STATE=Path(os.getenv('KC8GW_APP_STATE',str(DATA_ROOT/'operations/v6')))
RPT_CONF=Path('/etc/asterisk/rpt.conf')
USBRADIO_CONF=Path('/etc/asterisk/usbradio.conf')
ECHOLINK_CONF=Path('/etc/asterisk/echolink.conf')
ENV_FILE=Path('/etc/kc8gw-dashboard.env')
