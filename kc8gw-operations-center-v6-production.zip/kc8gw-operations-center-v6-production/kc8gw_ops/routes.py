from __future__ import annotations
import os,time,re,json
from functools import wraps
from flask import Blueprint,render_template,jsonify,request,Response,send_file
import psutil
from . import db
from .paths import DATA_ROOT,ARCHIVE_DIR,BACKUP_ROOT,APP_STATE,RPT_CONF,USBRADIO_CONF,ECHOLINK_CONF
from .system import run,active,asterisk,cpu_temp,parse_stats,links,storage,smart_summary
from .configsvc import snapshot,apply,backup_config
from .audiosvc import scan,clips,resolve_clip
from .backupsvc import create,list_backups,restore_asterisk_configs
from .diagnostics import collect as diagnostics_collect
from .maintenance import settings as maintenance_settings,save_settings as maintenance_save,preview as maintenance_preview,cleanup as maintenance_cleanup,reindex as maintenance_reindex,vacuum as maintenance_vacuum,storage_summary as maintenance_storage
from .alerts import current as alerts_current,history as alerts_history,sync as alerts_sync
from .production import status as production_status, save as production_save, public_enabled
from .remote import collect as remote_collect
from .hardening import status as hardening_status, start_soak, reset_soak
bp=Blueprint('main',__name__)
VERSION='6.0.1-production'; NODE=os.getenv('KC8GW_NODE','58506'); ECHO=os.getenv('KC8GW_ECHOLINK','543118'); USER=os.getenv('KC8GW_DASH_USER','greg'); PASSWORD=os.getenv('KC8GW_DASH_PASSWORD','')
NODE_RE=re.compile(r'^\d{1,10}$')
def auth(fn):
    @wraps(fn)
    def w(*a,**k):
        if not PASSWORD:return fn(*a,**k)
        x=request.authorization
        if not x or x.username!=USER or x.password!=PASSWORD:return Response('Authentication required',401,{'WWW-Authenticate':'Basic realm="KC8GW Operations Center"'})
        return fn(*a,**k)
    return w
@bp.get('/')
@auth
def home():return render_template('index.html',version=VERSION,node=NODE,echolink=ECHO,page='operations')
@bp.get('/audio')
@auth
def audio_page():return render_template('audio.html',version=VERSION,page='audio')
@bp.get('/config')
@auth
def config_page():return render_template('config.html',version=VERSION,page='config')
@bp.get('/storage')
@auth
def storage_page():return render_template('storage.html',version=VERSION,page='storage')
@bp.get('/backups')
@auth
def backups_page():return render_template('backups.html',version=VERSION,page='backups')
@bp.get('/logs')
@auth
def logs_page():return render_template('logs.html',version=VERSION,page='logs')
@bp.get('/diagnostics')
@auth
def diagnostics_page():return render_template('diagnostics.html',version=VERSION,page='diagnostics')
@bp.get('/maintenance')
@auth
def maintenance_page():return render_template('maintenance.html',version=VERSION,page='maintenance')
@bp.get('/alerts')
@auth
def alerts_page():return render_template('alerts.html',version=VERSION,page='alerts')
@bp.get('/remote')
@auth
def remote_page():return render_template('remote.html',version=VERSION,page='remote')
@bp.get('/api/status')
@auth
def status():
    # Prefer the shared live-state cache written by the station monitor.
    # This keeps browser refreshes lightweight and prevents duplicate Asterisk/SMART polling.
    live={}
    live_fresh=False
    try:
        live=json.loads((APP_STATE/'live_state.json').read_text())
        live_fresh=(time.time()-float(live.get('ts',0))) < 6
    except Exception:
        live={}
    if live_fresh:
        radio=live.get('radio') or {}
        link_rows=live.get('link_rows') or []
        ast_ok=bool(live.get('asterisk',live.get('node_ok',False)))
        echo_loaded=bool(live.get('echolink',False))
        allmon_ok=bool(live.get('allmon3',False))
        tail_ok=bool(live.get('tailscale',False))
    else:
        c,raw=asterisk(f'rpt stats {NODE}')
        ecode,eout=asterisk('module show like echolink')
        radio=parse_stats(raw) if c==0 else {}
        link_rows=links(NODE)
        ast_ok=active('asterisk') and c==0
        echo_loaded=ecode==0 and 'chan_echolink' in eout.lower()
        allmon_ok=active('allmon3')
        tail_ok=active('tailscaled')
    s=storage()
    return jsonify(
        ok=ast_ok,node=NODE,echolink=ECHO,asterisk=ast_ok,allmon3=allmon_ok,tailscale=tail_ok,
        radio=radio,links=link_rows,
        echolink_status={'loaded':echo_loaded,'state':'ONLINE' if echo_loaded else 'OFFLINE'},
        cpu_temp_c=cpu_temp(),cpu_percent=psutil.cpu_percent(.02),memory_percent=psutil.virtual_memory().percent,
        disk_percent=psutil.disk_usage('/').percent,storage=s,uptime=int(time.time()-psutil.boot_time()),
        live=live,alerts=alerts_current(),live_fresh=live_fresh
    )
@bp.post('/api/allstar/connect')
@auth
def connect_node():
    p=request.get_json(silent=True) or {}; target=str(p.get('node','')).strip(); mode=str(p.get('mode','3'))
    if not NODE_RE.fullmatch(target) or mode not in {'2','3'}:return jsonify(ok=False,message='Invalid node or mode.'),400
    code,out=run(['/usr/local/sbin/kc8gw-radioctl','connect',NODE,mode,target],12); db.add_event('allstar','Connect requested',target); return jsonify(ok=code==0,message=out or f'Connection requested: {target}'),(200 if code==0 else 500)
@bp.post('/api/allstar/disconnect')
@auth
def disconnect_node():
    p=request.get_json(silent=True) or {}; target=str(p.get('node','')).strip(); args=['/usr/local/sbin/kc8gw-radioctl','disconnect',NODE]
    if target:
        if not NODE_RE.fullmatch(target):return jsonify(ok=False,message='Invalid node.'),400
        args.append(target)
    code,out=run(args,12); db.add_event('allstar','Disconnect requested',target or 'ALL'); return jsonify(ok=code==0,message=out or 'Disconnect requested.'),(200 if code==0 else 500)
@bp.get('/api/favorites')
@auth
def fav_get():return jsonify(ok=True,favorites=db.favorites())
@bp.post('/api/favorites')
@auth
def fav_save():return jsonify(ok=True,favorites=db.save_favorites((request.get_json(silent=True) or {}).get('favorites',[])))
@bp.get('/api/timeline')
@auth
def timeline():return jsonify(ok=True,events=db.timeline(int(request.args.get('limit','80'))))
@bp.get('/api/config')
@auth
def get_config():return jsonify(ok=True,config=snapshot())
@bp.post('/api/config/apply')
@auth
def apply_config():
    try:return jsonify(ok=True,backup=apply((request.get_json(silent=True) or {}).get('changes',[])),message='Configuration saved, Asterisk restarted, and node verified.')
    except Exception as e:return jsonify(ok=False,message=f'Apply failed; previous configuration restored. {e}'),500
@bp.post('/api/config/backup')
@auth
def cfg_backup():
    try:
        p=backup_config('manual'); db.add_event('config','Config snapshot',p.name); return jsonify(ok=True,message=f'Config snapshot created: {p.name}')
    except Exception as e:return jsonify(ok=False,message=str(e)),500
@bp.get('/api/audio/clips')
@auth
def audio_clips():
    scan(500)
    return jsonify(ok=True,clips=clips(int(request.args.get('limit','80')),request.args.get('q','').strip(),request.args.get('source','').strip()))
@bp.get('/api/audio/file/<path:rel>')
@auth
def audio_file(rel):
    p=resolve_clip(rel)
    if not p:return Response('Recording not found',404)
    return send_file(p,mimetype='audio/wav',conditional=True,max_age=0)
@bp.get('/api/audio/download/<path:rel>')
@auth
def audio_download(rel):
    p=resolve_clip(rel)
    if not p:return Response('Recording not found',404)
    return send_file(p,mimetype='audio/wav',as_attachment=True,download_name=p.name,max_age=0)
@bp.get('/api/storage')
@auth
def api_storage():return jsonify(ok=True,storage=storage(),smart=smart_summary(),archive=str(ARCHIVE_DIR),backup_root=str(BACKUP_ROOT),database=str(db.DB_PATH))
@bp.post('/api/backups/create')
@auth
def backup_now():
    try:
        p=create('manual');return jsonify(ok=True,message=f'Backup created: {p.name}')
    except Exception as e:return jsonify(ok=False,message=str(e)),500
@bp.get('/api/backups')
@auth
def backups():return jsonify(ok=True,backups=list_backups())
@bp.post('/api/backups/restore')
@auth
def backup_restore():
    bid=str((request.get_json(silent=True) or {}).get('id','')).strip()
    if not bid:return jsonify(ok=False,message='Select a backup first.'),400
    try:
        result=restore_asterisk_configs(bid,NODE)
        return jsonify(ok=True,message='Asterisk configuration restored and node verified.',result=result)
    except Exception as e:return jsonify(ok=False,message=f'Restore failed and was rolled back: {e}'),500
@bp.get('/api/diagnostics')
@auth
def api_diagnostics():return jsonify(diagnostics_collect(NODE))

@bp.get('/api/maintenance')
@auth
def api_maintenance():
    return jsonify(ok=True,preview=maintenance_preview(),storage=maintenance_storage())
@bp.post('/api/maintenance/settings')
@auth
def api_maintenance_settings():
    try:return jsonify(ok=True,settings=maintenance_save(request.get_json(silent=True) or {}),message='Maintenance settings saved.')
    except Exception as e:return jsonify(ok=False,message=str(e)),400
@bp.post('/api/maintenance/cleanup')
@auth
def api_maintenance_cleanup():
    try:return jsonify(ok=True,result=maintenance_cleanup(),message='Cleanup completed.')
    except Exception as e:return jsonify(ok=False,message=str(e)),500
@bp.post('/api/maintenance/reindex')
@auth
def api_maintenance_reindex():
    try:return jsonify(ok=True,count=maintenance_reindex(),message='Audio archive re-indexed.')
    except Exception as e:return jsonify(ok=False,message=str(e)),500
@bp.post('/api/maintenance/vacuum')
@auth
def api_maintenance_vacuum():
    try:return jsonify(ok=True,size=maintenance_vacuum(),message='SQLite database optimized.')
    except Exception as e:return jsonify(ok=False,message=str(e)),500

@bp.get('/api/alerts')
@auth
def api_alerts():
    d=diagnostics_collect(NODE); alerts_sync(d.get('alerts',[]))
    return jsonify(ok=True,current=alerts_current(),history=alerts_history(int(request.args.get('limit','200'))),diagnostics=d)

@bp.get('/public-status-preview')
@auth
def public_status_preview():
    return render_template('public_status.html',version=VERSION,page='public-status')

@bp.get('/api/remote')
@auth
def api_remote():return jsonify(ok=True,remote=remote_collect())

@bp.get('/api/public/status')
def public_status():
    if not public_enabled():
        return jsonify(ok=False,message='Public status API is disabled.'),404
    c,raw=asterisk(f'rpt stats {NODE}'); ecode,eout=asterisk('module show like echolink')
    live={}
    try: live=json.loads((APP_STATE/'live_state.json').read_text())
    except Exception: pass
    return jsonify(
        ok=True,
        schema_version='1.0',
        callsign='KC8GW',
        node=NODE,
        node_online=(c==0),
        echolink_online=(ecode==0 and 'chan_echolink' in eout.lower()),
        active_links=len(links(NODE)),
        rx=bool(live.get('rx',False)),
        tx=bool(live.get('tx',False)),
        station_uptime_seconds=int(time.time()-psutil.boot_time()),
        data_drive_ok=bool(storage().get('mounted',False)),
        updated=int(time.time()),
    )

@bp.get('/production')
@auth
def production_page():
    return render_template('production.html',version=VERSION,page='production')

@bp.get('/api/production')
@auth
def api_production():
    d=diagnostics_collect(NODE)
    critical=[a for a in d.get('alerts',[]) if str(a.get('severity','')).lower() in {'critical','error'}]
    warning=[a for a in d.get('alerts',[]) if str(a.get('severity','')).lower() in {'warning','warn'}]
    ps=production_status()
    return jsonify(ok=True,ready=(not critical),critical=critical,warnings=warning,production=ps,diagnostics=d)

@bp.post('/api/production/public-status')
@auth
def api_production_public_status():
    payload=request.get_json(silent=True) or {}
    enabled=bool(payload.get('enabled',False))
    s=production_save({'public_status_enabled':enabled})
    db.add_event('system','Public status '+('enabled' if enabled else 'disabled'),'v6 production settings')
    return jsonify(ok=True,production=s,message='Public status '+('enabled' if enabled else 'disabled')+'.')


@bp.get('/hardening')
@auth
def hardening_page():
    return render_template('hardening.html',version=VERSION,page='hardening')

@bp.get('/api/hardening')
@auth
def api_hardening():
    d=diagnostics_collect(NODE)
    return jsonify(ok=True,hardening=hardening_status(d),diagnostics=d)

@bp.post('/api/hardening/start')
@auth
def api_hardening_start():
    s=start_soak(); db.add_event('system','V6 soak test started','24-hour production soak')
    return jsonify(ok=True,state=s,message='24-hour soak test started.')

@bp.post('/api/hardening/reset')
@auth
def api_hardening_reset():
    s=reset_soak(); db.add_event('system','V6 soak test reset','production hardening')
    return jsonify(ok=True,state=s,message='Soak test reset.')

@bp.get('/api/logs/<service>')
@auth
def logs(service):
    allowed={'asterisk':'asterisk','allmon3':'allmon3','operations':'kc8gw-operations-v6','monitor':'kc8gw-v6-monitor'}
    if service not in allowed:return jsonify(ok=False,message='Invalid service'),400
    code,out=run(['/usr/bin/journalctl','-u',allowed[service],'-n','160','--no-pager'],8);return jsonify(ok=code==0,text=out),(200 if code==0 else 500)
@bp.post('/api/service/<name>/restart')
@auth
def restart(name):
    if name not in {'asterisk','allmon3','kc8gw-operations-v6','kc8gw-v6-monitor'}:return jsonify(ok=False,message='Not allowed'),403
    code,out=run(['/usr/bin/systemctl','restart',name],20);db.add_event('system','Service restart',name);return jsonify(ok=code==0,message=out or f'{name} restarted'),(200 if code==0 else 500)
@bp.get('/health')
def health():return jsonify(ok=True,version=VERSION)
