from __future__ import annotations
import re,shutil,time
from pathlib import Path
from datetime import datetime
from .paths import RPT_CONF,USBRADIO_CONF,ECHOLINK_CONF,BACKUP_ROOT,APP_STATE
from .system import run,active,asterisk
from .db import add_event
NODE='58506'
ALLOWED={str(RPT_CONF):{NODE:{'duplex','hangtime','idrecording'}},str(USBRADIO_CONF):{NODE:{'rxboost','carrierfrom','ctcssfrom','txctcssdefault','rxctcssfreqs','txctcssfreqs','rxsquelchdelay','voxhangtime','rxctcssoverride'}},str(ECHOLINK_CONF):{'el0':{'name','qth','freq','tone','lat','lon'}}}
def read_values(path,section,keys):
    vals={k:'' for k in keys}; current=None
    if not path.exists():return vals
    for raw in path.read_text(errors='ignore').splitlines():
        s=raw.strip()
        if s.startswith('['): current=s[1:s.find(']')].strip(); continue
        if current!=section or not s or s.startswith((';','#')) or '=' not in s:continue
        k,v=s.split('=',1); k=k.strip()
        if k in vals: vals[k]=v.split(';',1)[0].strip()
    return vals
def snapshot():
    return {'rpt':read_values(RPT_CONF,NODE,['duplex','hangtime','idrecording','rxchannel','archivedir','archiveformat','archiveaudio']), 'usbradio':read_values(USBRADIO_CONF,NODE,['rxboost','carrierfrom','ctcssfrom','txctcssdefault','rxctcssfreqs','txctcssfreqs','rxsquelchdelay','voxhangtime','rxctcssoverride']), 'echolink':read_values(ECHOLINK_CONF,'el0',['call','name','qth','node','freq','tone','lat','lon'])}
def replace_value(path,section,key,value):
    lines=path.read_text(errors='ignore').splitlines(); out=[]; current=None; found=False; replaced=False
    for raw in lines:
        s=raw.strip()
        if s.startswith('['):
            newsec=s[1:s.find(']')].strip()
            if current==section and found and not replaced: out.append(f'{key} = {value}'); replaced=True
            current=newsec; found=found or current==section; out.append(raw); continue
        if current==section and not s.startswith((';','#')) and '=' in s and s.split('=',1)[0].strip()==key:
            pref=raw[:len(raw)-len(raw.lstrip())]; out.append(f'{pref}{key} = {value}'); replaced=True
        else:out.append(raw)
    if not found: raise ValueError(f'Section [{section}] not found')
    if not replaced: out.append(f'{key} = {value}')
    path.write_text('\n'.join(out)+'\n')
def backup_config(kind='manual'):
    stamp=datetime.now().strftime('%Y%m%d-%H%M%S'); target=BACKUP_ROOT/'config'/f'{kind}-{stamp}'; target.mkdir(parents=True,mode=0o700,exist_ok=False)
    for src in [RPT_CONF,USBRADIO_CONF,ECHOLINK_CONF]:
        if src.exists():shutil.copy2(src,target/src.name)
    return target
def apply(changes):
    b=backup_config('prechange')
    try:
        for item in changes:
            path=str(item.get('path','')); sec=str(item.get('section','')); key=str(item.get('key','')); value=str(item.get('value','')).strip()
            if path not in ALLOWED or sec not in ALLOWED[path] or key not in ALLOWED[path][sec]: raise ValueError(f'Write not allowed: {key}')
            if len(value)>180:raise ValueError('Value too long')
            replace_value(Path(path),sec,key,value)
        code,out=run(['/usr/bin/systemctl','restart','asterisk'],25)
        time.sleep(2)
        code2,stats=asterisk(f'rpt stats {NODE}',8)
        if code or not active('asterisk') or code2 or 'STATISTICS' not in stats: raise RuntimeError(out or 'node verification failed')
        add_event('config','Configuration applied',f'Backup {b.name}')
        return b.name
    except Exception:
        for dst in [RPT_CONF,USBRADIO_CONF,ECHOLINK_CONF]:
            src=b/dst.name
            if src.exists():shutil.copy2(src,dst)
        run(['/usr/bin/systemctl','restart','asterisk'],25); raise
