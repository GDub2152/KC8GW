from __future__ import annotations
import os,time
from datetime import datetime
from pathlib import Path
import psutil
from . import db
from .paths import DATA_ROOT,ARCHIVE_DIR,APP_STATE,DB_PATH,RPT_CONF
from .system import active,cpu_temp,storage,smart_summary,asterisk

def _latest_backup():
    try:
        with db.connect() as c:
            r=c.execute('select ts,kind,path,verified from backups order by ts desc limit 1').fetchone()
        return dict(r) if r else None
    except Exception:
        return None

def _age_seconds(path:Path):
    try:return max(0,time.time()-path.stat().st_mtime)
    except Exception:return None

def collect(node='58506'):
    s=storage(); temp=cpu_temp(); mem=psutil.virtual_memory().percent; cpu=psutil.cpu_percent(.03)
    latest=_latest_backup(); live=APP_STATE/'live_state.json'; live_age=_age_seconds(live)
    code,raw=asterisk(f'rpt stats {node}',6)
    smart=smart_summary()
    checks=[]
    def add(key,label,ok,detail='',severity='critical'):
        checks.append({'key':key,'label':label,'ok':bool(ok),'detail':str(detail),'severity':severity})
    add('asterisk','Asterisk service',active('asterisk'),'running' if active('asterisk') else 'not running')
    add('node','AllStar node response',code==0,'node responds' if code==0 else (raw or 'no response'))
    add('monitor','Live monitor freshness',live_age is not None and live_age<6, f'{live_age:.1f}s old' if live_age is not None else 'no live_state.json')
    add('data','KC8GW-DATA mounted',s.get('mounted'),f"{s.get('free',0)/1024**3:.1f} GB free")
    add('archive','Archive directory writable',ARCHIVE_DIR.exists() and os.access(ARCHIVE_DIR,os.W_OK),str(ARCHIVE_DIR))
    add('database','SQLite storage writable',DB_PATH.parent.exists() and os.access(DB_PATH.parent,os.W_OK),str(DB_PATH))
    add('allmon3','Allmon3 service',active('allmon3'),'running' if active('allmon3') else 'offline','warning')
    add('tailscale','Tailscale service',active('tailscaled'),'running' if active('tailscaled') else 'offline','warning')
    if smart.get('available'):
        add('smart','Data drive SMART',smart.get('ok') and str(smart.get('status','')).upper() not in {'FAILED','BAD'},smart.get('status','UNKNOWN'),'warning')
    if latest:
        try:
            ts=datetime.fromisoformat(latest['ts']); age=(datetime.now()-ts).total_seconds()
            add('backup','Recent backup',age<36*3600,f"{age/3600:.1f}h old • {latest['kind']}",'warning')
        except Exception:add('backup','Recent backup',False,'invalid backup timestamp','warning')
    else:add('backup','Recent backup',False,'no cataloged backup','warning')
    # threshold checks as explicit health rows
    add('temperature','CPU temperature',temp is None or temp<80,f'{temp if temp is not None else "--"} °C','warning')
    add('memory','Memory pressure',mem<92,f'{mem:.1f}%','warning')
    add('cpu','CPU load',cpu<95,f'{cpu:.1f}%','warning')
    warn_free=float(db.setting('maintenance.warn_free_percent',10)); max_used=100-warn_free
    add('data_free','Data drive free space',(not s.get('mounted')) or s.get('percent',100)<max_used,f"{s.get('percent',0):.1f}% used • warn below {warn_free:.0f}% free",'warning')
    alerts=[]
    for c in checks:
        if not c['ok']:
            alerts.append({'severity':c['severity'],'title':c['label'],'detail':c['detail'],'key':c['key']})
    return {'ok':not any(a['severity']=='critical' for a in alerts),'checks':checks,'alerts':alerts,'summary':{
        'cpu_percent':cpu,'memory_percent':mem,'cpu_temp_c':temp,'storage':s,'live_age_seconds':live_age,'latest_backup':latest,'smart':smart}}
