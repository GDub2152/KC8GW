from __future__ import annotations
from datetime import datetime
from . import db


def sync(alerts):
    """Persist alert state transitions without generating duplicate history rows."""
    incoming={str(a.get('key','')):a for a in alerts if a.get('key')}
    now=datetime.now().isoformat(timespec='seconds')
    with db.connect() as c:
        current={r['key']:dict(r) for r in c.execute('select * from alerts_current')}
        for key,a in incoming.items():
            sev=str(a.get('severity','warning'))[:16]
            title=str(a.get('title','Alert'))[:120]
            detail=str(a.get('detail',''))[:500]
            old=current.get(key)
            if not old:
                c.execute('insert or replace into alerts_current(key,severity,title,detail,opened_ts,updated_ts) values(?,?,?,?,?,?)',(key,sev,title,detail,now,now))
                c.execute('insert into alert_history(ts,key,severity,event,title,detail) values(?,?,?,?,?,?)',(now,key,sev,'OPEN',title,detail))
            elif old['severity']!=sev or old['title']!=title or old['detail']!=detail:
                c.execute('update alerts_current set severity=?,title=?,detail=?,updated_ts=? where key=?',(sev,title,detail,now,key))
                c.execute('insert into alert_history(ts,key,severity,event,title,detail) values(?,?,?,?,?,?)',(now,key,sev,'UPDATE',title,detail))
        for key,old in current.items():
            if key not in incoming:
                c.execute('delete from alerts_current where key=?',(key,))
                c.execute('insert into alert_history(ts,key,severity,event,title,detail) values(?,?,?,?,?,?)',(now,key,old['severity'],'CLEAR',old['title'],old['detail']))


def current():
    with db.connect() as c:
        return [dict(r) for r in c.execute("select * from alerts_current order by case severity when 'critical' then 0 else 1 end, opened_ts desc")]


def history(limit=200):
    limit=max(1,min(int(limit),1000))
    with db.connect() as c:
        return [dict(r) for r in c.execute('select * from alert_history order by id desc limit ?',(limit,))]
