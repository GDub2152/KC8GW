from __future__ import annotations
import os,time
from functools import wraps
from flask import Flask,request,Response
from .db import init_db

def create_app():
    from .routes import bp
    app=Flask(__name__,template_folder='../templates',static_folder='../static')
    init_db(); app.register_blueprint(bp)
    return app
