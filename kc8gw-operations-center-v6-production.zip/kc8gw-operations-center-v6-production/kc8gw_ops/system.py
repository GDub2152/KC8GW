from __future__ import annotations
import subprocess,time,psutil,shutil,os
from pathlib import Path
from .paths import DATA_ROOT

def run(args,timeout=10):
    try:
        p=subprocess.run(args,text=True,capture_output=True,timeout=timeout); return p.returncode,((p.stdout or '')+(p.stderr or '')).strip()
    except subprocess.TimeoutExpired:return 124,'Command timed out.'
    except Exception as e:return 1,str(e)
def active(name): return run(['/usr/bin/systemctl','is-active','--quiet',name],3)[0]==0
def asterisk(cmd,timeout=8): return run(['/usr/sbin/asterisk','-rx',cmd],timeout)
def cpu_temp():
    try:
        t=psutil.sensors_temperatures()
        for vals in t.values():
            if vals:return round(float(vals[0].current),1)
    except Exception:pass
    try:return round(int(Path('/sys/class/thermal/thermal_zone0/temp').read_text().strip())/1000,1)
    except Exception:return None
def parse_stats(raw):
    out={}
    for line in raw.splitlines():
        if ':' not in line: continue
        k,v=line.split(':',1); lk=k.strip().lower(); v=v.strip()
        if 'signal on input' in lk: out['signal']=v
        elif 'identifier state' in lk: out['identifier']=v
        elif 'keyups today' in lk: out['keyups_today']=v
        elif 'tx time today' in lk: out['tx_time_today']=v
        elif lk=='uptime': out['uptime']=v
    return out
def links(node):
    code,raw=asterisk(f'rpt lstats {node}')
    rows=[]
    if code==0:
        for line in raw.splitlines():
            s=line.strip()
            if not s or s.startswith('NODE') or set(s)=={'-'}:continue
            rows.append(s)
    return rows
def storage():
    mounted=DATA_ROOT.exists() and DATA_ROOT.is_mount()
    try:
        u=psutil.disk_usage(str(DATA_ROOT)); data={'mounted':mounted,'total':u.total,'used':u.used,'free':u.free,'percent':u.percent}
    except Exception:data={'mounted':mounted,'total':0,'used':0,'free':0,'percent':0}
    data['label']='KC8GW-DATA'; return data
def data_device():
    code,out=run(['/usr/bin/findmnt','-n','-o','SOURCE',str(DATA_ROOT)],4)
    source=(out.splitlines()[0].strip() if code==0 and out.strip() else '')
    if not source.startswith('/dev/'):
        return '/dev/sda'
    code,parent=run(['/usr/bin/lsblk','-ndo','PKNAME',source],4)
    if code==0 and parent.strip():
        return '/dev/'+parent.splitlines()[0].strip()
    return source

def smart_summary():
    if not shutil.which('smartctl'):
        return {'available':False,'status':'smartctl not installed','device':data_device()}
    dev=data_device()
    code,out=run(['/usr/sbin/smartctl','-H',dev],8)
    status='UNKNOWN'
    low=out.lower()
    for line in out.splitlines():
        if 'overall-health' in line.lower() or 'smart health status' in line.lower():
            status=line.split(':',1)[-1].strip()
    # smartctl uses a bitmask exit status; parse the health text rather than treating code 2 as success.
    ok=('passed' in status.lower() or status.lower() in {'ok','healthy'}) and 'failed' not in low
    return {'available':True,'status':status,'ok':ok,'device':dev,'exit_code':code}
