#!/usr/bin/env python3
from pathlib import Path
import sys
node=sys.argv[1] if len(sys.argv)>1 else '58506'; archive=sys.argv[2] if len(sys.argv)>2 else '/mnt/kc8gw-data/audio/archive'
p=Path('/etc/asterisk/rpt.conf'); lines=p.read_text().splitlines(); start=None; end=len(lines)
for i,line in enumerate(lines):
    if line.strip().startswith(f'[{node}]'): start=i; continue
    if start is not None and i>start and line.strip().startswith('['): end=i; break
if start is None:raise SystemExit(f'[{node}] not found')
section=lines[start:end]
def upsert(key,value):
    global section
    for i,raw in enumerate(section):
        s=raw.strip()
        if not s.startswith((';','#')) and '=' in s and s.split('=',1)[0].strip()==key:
            section[i]=f'{key} = {value}';return
    section.append(f'{key} = {value}')
upsert('archivedir',archive);upsert('archiveformat','wav');upsert('archiveaudio','yes')
lines[start:end]=section;p.write_text('\n'.join(lines)+'\n');print(f'Archive configured: {archive}')
