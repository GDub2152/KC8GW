#!/usr/bin/env python3
import sys
sys.path.insert(0,'/opt/kc8gw-operations-v5')
from kc8gw_ops.db import init_db
from kc8gw_ops.audiosvc import scan
init_db();print(f'Indexed {len(scan(500))} recent clips')
