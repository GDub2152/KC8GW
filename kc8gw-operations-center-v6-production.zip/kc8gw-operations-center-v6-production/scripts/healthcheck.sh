#!/usr/bin/env bash
set -u
fail=0
ok(){ printf 'OK   %s\n' "$*"; }
bad(){ printf 'FAIL %s\n' "$*"; fail=1; }
warn(){ printf 'WARN %s\n' "$*"; }
echo 'KC8GW Operations Center V6 production health check'
systemctl is-active --quiet kc8gw-operations-v6 && ok 'web service active' || bad 'web service inactive'
systemctl is-active --quiet kc8gw-v6-monitor && ok 'monitor service active' || bad 'monitor service inactive'
mountpoint -q /mnt/kc8gw-data && ok 'KC8GW-DATA mounted' || bad 'KC8GW-DATA not mounted'
curl -fsS http://127.0.0.1:8798/health >/dev/null && ok 'backend health endpoint' || bad 'backend health endpoint'
code=$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:8110/ || true)
[[ "$code" == 401 || "$code" == 200 ]] && ok "Nginx 8110 responds ($code)" || bad "Nginx 8110 response ($code)"
/usr/sbin/asterisk -rx 'rpt stats 58506' 2>/dev/null | grep -q 'STATISTICS' && ok 'AllStar node 58506 responds' || bad 'AllStar node 58506 not responding'
nginx -t >/dev/null 2>&1 && ok 'Nginx configuration valid' || bad 'Nginx configuration invalid'
if command -v smartctl >/dev/null 2>&1; then ok 'smartctl installed'; else warn 'smartctl not installed (optional)'; fi
printf '\nRunning KC8GW units:\n'
systemctl --type=service --state=running --no-legend | grep -E 'kc8gw|asterisk|allmon3' || true
exit "$fail"
