#!/usr/bin/env python3
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
from kc8gw_ops.backupsvc import create, scheduled
if len(sys.argv)>1 and sys.argv[1]=='scheduled':
    scheduled(); print('Scheduled backup/rotation complete')
else:
    p=create('manual'); print(p)
