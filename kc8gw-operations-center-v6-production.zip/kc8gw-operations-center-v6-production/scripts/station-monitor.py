#!/usr/bin/env python3
from __future__ import annotations
import json, os, time, sys
from pathlib import Path
PROJECT_ROOT=Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0,str(PROJECT_ROOT))
from kc8gw_ops import db
from kc8gw_ops.alerts import sync as sync_alerts
from kc8gw_ops.diagnostics import collect as diagnostics_collect
from kc8gw_ops.paths import APP_STATE
from kc8gw_ops.system import asterisk, active, parse_stats, links, storage

NODE=os.getenv('KC8GW_NODE','58506')
STATE=APP_STATE/'live_state.json'
APP_STATE.mkdir(parents=True,exist_ok=True)

def tx_seconds(v):
    try:
        p=str(v or '').split(':')
        if len(p)!=4:return 0.0
        return int(p[0])*3600+int(p[1])*60+int(p[2])+int(p[3])/1000.0
    except Exception:return 0.0

def link_nodes(rows):
    out={}
    for row in rows:
        p=row.split()
        if p:out[p[0]]=row
    return out

def write_state(d):
    tmp=STATE.with_suffix('.tmp')
    tmp.write_text(json.dumps(d,separators=(',',':')))
    tmp.replace(STATE)

def emit(cat,event,detail=''):
    try:db.add_event(cat,event,detail)
    except Exception:pass

def main():
    db.init_db()
    prev={}
    last_tx=0.0
    tx_active=False
    tx_quiet=0
    echo=False
    allmon=False
    tail=False
    data_mounted=False
    last_slow=0.0
    last_storage=0.0
    last_diag=0.0
    while True:
        started=time.monotonic()
        now=time.time()
        # Fast path: radio state + current links only.
        code,raw=asterisk(f'rpt stats {NODE}',5)
        radio=parse_stats(raw) if code==0 else {}
        rows=links(NODE)
        ln=link_nodes(rows)

        # Slow path: service/EchoLink checks every 5 seconds.
        if now-last_slow >= 5:
            echo_code,echo_out=asterisk('module show like echolink',4)
            echo=echo_code==0 and 'chan_echolink' in echo_out.lower()
            allmon=active('allmon3')
            tail=active('tailscaled')
            last_slow=now

        # Disk mount check every 10 seconds.
        if now-last_storage >= 10:
            data_mounted=storage().get('mounted',False)
            last_storage=now

        cur={
            'ts':int(now),'node_ok':code==0,'asterisk':code==0,
            'rx':radio.get('signal')=='YES','radio':radio,
            'links':sorted(ln),'link_rows':rows,
            'allmon3':allmon,'tailscale':tail,'echolink':echo,
            'data_mounted':data_mounted,'tx_time_today':radio.get('tx_time_today','---')
        }
        tx=tx_seconds(radio.get('tx_time_today'))
        if tx>last_tx+0.02:
            tx_active=True;tx_quiet=0
        else:
            tx_quiet+=1
            if tx_quiet>=2:tx_active=False
        last_tx=max(last_tx,tx);cur['tx']=tx_active

        if prev:
            if cur['rx']!=prev.get('rx'):emit('rf','RX START' if cur['rx'] else 'RX END','Local receiver')
            if cur['tx']!=prev.get('tx'):emit('rf','TX START' if cur['tx'] else 'TX END','Node transmitter')
            added=set(cur['links'])-set(prev.get('links',[]));removed=set(prev.get('links',[]))-set(cur['links'])
            for n in sorted(added):emit('allstar','LINK CONNECTED',n)
            for n in sorted(removed):emit('allstar','LINK DISCONNECTED',n)
            for k,label in [('asterisk','Asterisk'),('echolink','EchoLink'),('allmon3','Allmon3'),('tailscale','Tailscale'),('data_mounted','Data drive')]:
                if cur[k]!=prev.get(k):emit('system',f'{label} '+('ONLINE' if cur[k] else 'OFFLINE'),'')
        write_state(cur);prev=cur

        # Full diagnostics (including SMART) only once per minute.
        if now-last_diag >= 60:
            try:sync_alerts(diagnostics_collect(NODE).get('alerts',[]))
            except Exception:pass
            last_diag=now

        elapsed=time.monotonic()-started
        time.sleep(max(0.15,1.0-elapsed))

if __name__=='__main__':main()
