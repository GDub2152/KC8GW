#!/usr/bin/env bash
set -euo pipefail
MODE=${1:---dry-run}
KEEP_SERVICE_REGEX='^(asterisk|allmon3|tailscaled|kc8gw-operations-v6|kc8gw-v6-monitor|kc8gw-dashboard)$'
OLD_SERVICES=(kc8gw-v5-backup kc8gw-v5-index kc8gw-operations-v4 kc8gw-operations-v41 kc8gw-operations-v5 kc8gw-operations-v51 kc8gw-v51-monitor kc8gw-operations-v52 kc8gw-v52-monitor kc8gw-operations-v53 kc8gw-v53-monitor kc8gw-operations-v54 kc8gw-v54-monitor kc8gw-operations-v55 kc8gw-v55-monitor kc8gw-operations-v56 kc8gw-v56-monitor kc8gw-operations-v57 kc8gw-v57-monitor kc8gw-operations-v58 kc8gw-v58-monitor kc8gw-operations-v59 kc8gw-v59-monitor)
OLD_DIRS=(/opt/kc8gw-operations-v4 /opt/kc8gw-dashboard-v41 /opt/kc8gw-operations-v41 /opt/kc8gw-operations-v5 /opt/kc8gw-operations-v51 /opt/kc8gw-operations-v52 /opt/kc8gw-operations-v53 /opt/kc8gw-operations-v54 /opt/kc8gw-operations-v55 /opt/kc8gw-operations-v56 /opt/kc8gw-operations-v57 /opt/kc8gw-operations-v58 /opt/kc8gw-operations-v59)
OLD_NGINX=(kc8gw-operations-v4 kc8gw-operations-v41 kc8gw-operations-v5 kc8gw-operations-v51 kc8gw-operations-v52 kc8gw-operations-v53 kc8gw-operations-v54 kc8gw-operations-v55 kc8gw-operations-v56 kc8gw-operations-v57 kc8gw-operations-v58 kc8gw-operations-v59)
BACK=/mnt/kc8gw-data/backups/pre-cleanup/$(date +%Y%m%d-%H%M%S)
echo "KC8GW old-preview cleanup: $MODE"
echo "V6 and the legacy kc8gw-dashboard are always preserved."
if [[ $MODE != --apply ]]; then
  echo "Would back up old units/sites to $BACK"
  for s in "${OLD_SERVICES[@]}"; do systemctl list-unit-files "$s.service" --no-legend 2>/dev/null | grep -q . && echo "Would disable/remove service: $s" || true; done
  for n in "${OLD_NGINX[@]}"; do [[ -e /etc/nginx/sites-enabled/$n || -e /etc/nginx/sites-available/$n ]] && echo "Would remove nginx preview: $n"; done
  for d in "${OLD_DIRS[@]}"; do [[ -d $d ]] && echo "Would archive/remove directory: $d"; done
  echo "Re-run with --apply after verifying http://<node>:8110/"
  exit 0
fi
mkdir -p "$BACK"/{systemd,nginx,opt}
for s in "${OLD_SERVICES[@]}"; do
  [[ $s =~ $KEEP_SERVICE_REGEX ]] && continue
  if systemctl list-unit-files "$s.service" --no-legend 2>/dev/null | grep -q .; then
    cp -a "/etc/systemd/system/$s.service" "$BACK/systemd/" 2>/dev/null || true
    systemctl disable --now "$s.service" 2>/dev/null || true
    rm -f "/etc/systemd/system/$s.service"
  fi
done
for n in "${OLD_NGINX[@]}"; do
  for p in /etc/nginx/sites-enabled/$n /etc/nginx/sites-available/$n; do [[ -e $p || -L $p ]] && cp -aL "$p" "$BACK/nginx/$n.$(basename $(dirname $p))" 2>/dev/null || true; rm -f "$p"; done
done
for d in "${OLD_DIRS[@]}"; do
  if [[ -d $d ]]; then tar -C /opt -czf "$BACK/opt/$(basename $d).tar.gz" "$(basename $d)" && rm -rf "$d"; fi
done
for t in kc8gw-v5-backup.timer kc8gw-v5-index.timer; do systemctl disable --now "$t" 2>/dev/null || true; rm -f "/etc/systemd/system/$t"; done
systemctl daemon-reload
nginx -t && systemctl reload nginx
echo "Cleanup complete. Backup: $BACK"
echo "Preserved: Asterisk, EchoLink config, Allmon3, Tailscale, KC8GW-DATA, legacy kc8gw-dashboard, and V6."
