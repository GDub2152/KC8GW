const $=id=>document.getElementById(id);
async function api(p){let r=await fetch(p),d=await r.json();if(!r.ok)throw new Error(d.message||'Request failed');return d}
let monitor=false,last='',timer=null;const player=$('player');
$('volume').oninput=()=>player.volume=Number($('volume').value)/100;
$('speed').onchange=()=>player.playbackRate=Number($('speed').value)||1;
$('stop').onclick=()=>{monitor=false;player.pause();$('audioMsg').textContent='MONITOR STOPPED'};
$('monitor').onclick=()=>{monitor=true;$('audioMsg').textContent='MONITORING FOR NEW TRANSMISSIONS';refresh(true)};
$('refreshAudio').onclick=()=>refresh(false);
$('search').addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(()=>refresh(false),250)});
function playClip(x){player.src=x.url;player.playbackRate=Number($('speed').value)||1;player.play().catch(()=>{});$('nowPlaying').textContent=x.name;$('clipTime').textContent=String(x.ts).replace('T',' ');$('audioMsg').textContent='PLAYING '+x.name}
function fmtDuration(v){v=Number(v);if(!v)return '--';let m=Math.floor(v/60),s=Math.round(v%60);return m?`${m}:${String(s).padStart(2,'0')}`:`${s}s`}
async function refresh(force=false){try{let q=encodeURIComponent($('search').value.trim()),d=await api('/api/audio/clips?limit=150&q='+q),c=$('clips');c.innerHTML='';$('clipCount').textContent=`${d.clips.length} RECORDING${d.clips.length===1?'':'S'}`;d.clips.forEach(x=>{let r=document.createElement('div');r.className='clip';let info=document.createElement('div');info.innerHTML=`<strong>${x.name}</strong><span>${String(x.ts).replace('T',' ')}</span><small>${Math.round(x.size/1024)} KB • ${fmtDuration(x.duration)}</small>`;let actions=document.createElement('div');actions.className='clip-actions';let b=document.createElement('button');b.textContent='▶ PLAY';b.onclick=()=>playClip(x);let a=document.createElement('a');a.href=x.download;a.textContent='DOWNLOAD';a.className='button-link';actions.append(b,a);r.append(info,actions);c.appendChild(r)});if(monitor&&d.clips.length&&d.clips[0].path!==last){let x=d.clips[0];if(last||force)playClip(x);last=x.path}}catch(e){$('audioMsg').textContent='AUDIO ERROR: '+e.message}}
refresh();setInterval(()=>refresh(false),2000);
