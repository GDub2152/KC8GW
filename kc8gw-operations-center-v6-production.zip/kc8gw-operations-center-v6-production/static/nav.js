(()=>{const p=document.body.dataset.page;document.querySelectorAll('.nav a[data-page]').forEach(a=>a.classList.toggle('active',a.dataset.page===p));const c=document.getElementById('clock');function t(){if(c)c.textContent=new Date().toLocaleTimeString()}t();setInterval(t,1000)})();

// V5.9 PWA: cache static shell assets only. Sensitive pages/APIs remain network-only.
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => navigator.serviceWorker.register('/static/sw.js').catch(() => {}));
}
