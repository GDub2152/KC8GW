#!/usr/bin/env bash
set -euo pipefail
SRC="$(cd "$(dirname "$0")" && pwd)"
TARGET=/opt/kc8gw-operations-v6
DATA=/mnt/kc8gw-data
STAMP=$(date +%Y%m%d-%H%M%S)
SAFE="$DATA/backups/pre-v6-unified/$STAMP"
UNIT_WEB=/etc/systemd/system/kc8gw-operations-v6.service
UNIT_MON=/etc/systemd/system/kc8gw-v6-monitor.service
NG_AV=/etc/nginx/sites-available/kc8gw-operations-v6
NG_EN=/etc/nginx/sites-enabled/kc8gw-operations-v6

echo "KC8GW Operations Center 6.0 Unified safe replacement installer"
if ! mountpoint -q "$DATA"; then echo "ERROR: $DATA is not mounted."; exit 1; fi
mkdir -p "$SAFE" "$DATA/operations/v6"
chmod 700 "$SAFE" "$DATA/operations/v6"

# Back up current V6 and its integration files.
[[ -d "$TARGET" ]] && cp -a "$TARGET" "$SAFE/current-v6"
[[ -e "$UNIT_WEB" ]] && cp -a "$UNIT_WEB" "$SAFE/"
[[ -e "$UNIT_MON" ]] && cp -a "$UNIT_MON" "$SAFE/"
[[ -e "$NG_AV" ]] && cp -a "$NG_AV" "$SAFE/"
[[ -L "$NG_EN" || -f "$NG_EN" ]] && cp -a "$NG_EN" "$SAFE/sites-enabled-kc8gw-operations-v6" || true
printf '%s\n' "$SAFE" > "$DATA/operations/v6/last-unified-backup-path"

# Validate source before stopping working V6.
python3 -m py_compile "$SRC/app.py" "$SRC"/kc8gw_ops/*.py "$SRC/scripts/station-monitor.py" "$SRC/scripts/index-audio.py" "$SRC/scripts/backup-now.py"

systemctl stop kc8gw-operations-v6.service kc8gw-v6-monitor.service 2>/dev/null || true
rm -rf "$TARGET.new"
mkdir -p "$TARGET.new"
cp -a "$SRC"/. "$TARGET.new"/
find "$TARGET.new" -type d -name __pycache__ -prune -exec rm -rf {} +
rm -rf "$TARGET"
mv "$TARGET.new" "$TARGET"

install -m 644 "$TARGET/systemd/kc8gw-operations-v6.service" "$UNIT_WEB"
install -m 644 "$TARGET/systemd/kc8gw-v6-monitor.service" "$UNIT_MON"
install -m 644 "$TARGET/nginx/kc8gw-operations-v6.conf" "$NG_AV"
ln -sfn "$NG_AV" "$NG_EN"

nginx -t
systemctl daemon-reload
systemctl enable kc8gw-operations-v6.service kc8gw-v6-monitor.service >/dev/null
systemctl restart kc8gw-v6-monitor.service kc8gw-operations-v6.service
systemctl reload nginx
sleep 3

if curl -fsS http://127.0.0.1:8798/health >/dev/null; then
  printf '%s\n' "$SAFE" > "$TARGET/ROLLBACK_PATH"
  echo "Unified V6 installed successfully."
  echo "Open: http://<PI-IP>:8110/"
  echo "Safety backup: $SAFE"
  exit 0
fi

echo "ERROR: Unified V6 health check failed. Restoring previous V6..."
systemctl stop kc8gw-operations-v6.service kc8gw-v6-monitor.service 2>/dev/null || true
rm -rf "$TARGET"
if [[ -d "$SAFE/current-v6" ]]; then cp -a "$SAFE/current-v6" "$TARGET"; fi
[[ -e "$SAFE/kc8gw-operations-v6.service" ]] && cp -a "$SAFE/kc8gw-operations-v6.service" "$UNIT_WEB"
[[ -e "$SAFE/kc8gw-v6-monitor.service" ]] && cp -a "$SAFE/kc8gw-v6-monitor.service" "$UNIT_MON"
[[ -e "$SAFE/kc8gw-operations-v6" ]] && cp -a "$SAFE/kc8gw-operations-v6" "$NG_AV"
systemctl daemon-reload
nginx -t || true
systemctl restart kc8gw-v6-monitor.service kc8gw-operations-v6.service 2>/dev/null || true
systemctl reload nginx 2>/dev/null || true
exit 1
