def test_import():
    from kc8gw_ops import create_app
    app=create_app(); assert app is not None
