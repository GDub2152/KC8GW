from pathlib import Path
import json,time
from .paths import DATA_ROOT, APP_STATE

STATE = DATA_ROOT / 'operations' / 'v6-hardening.json'

def _load():
    try:
        return json.loads(STATE.read_text())
    except Exception:
        return {'soak_started': 0, 'notes': '', 'updated': 0}

def save(values):
    cur=_load(); cur.update(values); cur['updated']=int(time.time())
    STATE.parent.mkdir(parents=True,exist_ok=True)
    tmp=STATE.with_suffix('.tmp'); tmp.write_text(json.dumps(cur,indent=2)); tmp.replace(STATE)
    return cur

def start_soak():
    return save({'soak_started':int(time.time())})

def reset_soak():
    return save({'soak_started':0})

def status(diag):
    s=_load(); now=int(time.time()); started=int(s.get('soak_started') or 0)
    soak=max(0,now-started) if started else 0
    blockers=[]; warnings=[]
    if not diag.get('asterisk'): blockers.append('Asterisk is offline')
    if not diag.get('node_ok'): blockers.append('Node 58506 is not responding')
    if not (diag.get('storage') or {}).get('mounted'): blockers.append('KC8GW-DATA is not mounted')
    if not diag.get('monitor_fresh'): blockers.append('Live monitor data is stale')
    if not diag.get('backup_ok'): warnings.append('No recent verified backup')
    if not diag.get('tailscale'): warnings.append('Tailscale is offline')
    if not diag.get('allmon3'): warnings.append('Allmon3 is offline')
    # 24-hour soak is recommended before production promotion.
    target=24*3600
    ready=(not blockers) and soak>=target
    return {
        'ready':ready,'blockers':blockers,'warnings':warnings,
        'soak_started':started,'soak_seconds':soak,'soak_target_seconds':target,
        'soak_complete':soak>=target,'state':s,'state_path':str(STATE)
    }
