from pathlib import Path
import json, time
from .paths import DATA_ROOT, APP_STATE

SETTINGS=DATA_ROOT / "operations" / "v6-production.json"

def _load():
    try:
        return json.loads(SETTINGS.read_text())
    except Exception:
        return {"public_status_enabled": False, "promoted": False}

def save(values):
    cur=_load(); cur.update(values); cur["updated"]=int(time.time())
    SETTINGS.parent.mkdir(parents=True,exist_ok=True)
    tmp=SETTINGS.with_suffix('.tmp'); tmp.write_text(json.dumps(cur,indent=2)); tmp.replace(SETTINGS)
    return cur

def public_enabled():
    return bool(_load().get("public_status_enabled",False))

def status():
    s=_load(); s["settings_path"]=str(SETTINGS); return s
