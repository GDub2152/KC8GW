#!/usr/bin/env bash
set -euo pipefail
SRC="$(cd "$(dirname "$0")" && pwd)"
TARGET=/opt/kc8gw-operations-v6
DATA=/mnt/kc8gw-data
STAMP=$(date +%Y%m%d-%H%M%S)
SAFE="$DATA/backups/pre-v6-rebuilt/$STAMP"
WEB=kc8gw-operations-v6.service
MON=kc8gw-v6-monitor.service
UNITS=(kc8gw-operations-v6.service kc8gw-v6-monitor.service kc8gw-v6-index.service kc8gw-v6-index.timer kc8gw-v6-backup.service kc8gw-v6-backup.timer)
NG_AV=/etc/nginx/sites-available/kc8gw-operations-v6
NG_EN=/etc/nginx/sites-enabled/kc8gw-operations-v6

echo 'KC8GW Operations Center 6.1 Rebuilt UI updater'
mountpoint -q "$DATA" || { echo "ERROR: $DATA is not mounted."; exit 1; }
mkdir -p "$SAFE" "$DATA/operations/v6" "$DATA/audio/archive" "$DATA/database" "$DATA/backups"
chmod 700 "$SAFE" "$DATA/operations/v6"

# Preserve current production install/integration.
[[ -d "$TARGET" ]] && cp -a "$TARGET" "$SAFE/current-v6"
mkdir -p "$SAFE/systemd" "$SAFE/nginx"
for u in "${UNITS[@]}"; do [[ -e /etc/systemd/system/$u ]] && cp -a /etc/systemd/system/$u "$SAFE/systemd/" || true; done
[[ -e "$NG_AV" ]] && cp -a "$NG_AV" "$SAFE/nginx/"
printf '%s\n' "$SAFE" > "$DATA/operations/v6/last-rebuilt-backup-path"

# Validate source before changing the running system.
python3 -m py_compile "$SRC/app.py" "$SRC"/kc8gw_ops/*.py "$SRC/scripts/station-monitor.py" "$SRC/scripts/index-audio.py" "$SRC/scripts/backup-now.py"
if command -v node >/dev/null 2>&1; then for f in "$SRC"/static/*.js; do node --check "$f" >/dev/null; done; fi
bash -n "$SRC/scripts/healthcheck.sh"

systemctl stop "$WEB" "$MON" 2>/dev/null || true
rm -rf "$TARGET.new"
mkdir -p "$TARGET.new"
cp -a "$SRC"/. "$TARGET.new"/
find "$TARGET.new" -type d -name __pycache__ -prune -exec rm -rf {} +
rm -rf "$TARGET"
mv "$TARGET.new" "$TARGET"

for u in "${UNITS[@]}"; do install -m 644 "$TARGET/systemd/$u" "/etc/systemd/system/$u"; done
install -m 644 "$TARGET/nginx/kc8gw-operations-v6.conf" "$NG_AV"
ln -sfn "$NG_AV" "$NG_EN"

nginx -t
systemctl daemon-reload
systemctl enable "$WEB" "$MON" kc8gw-v6-index.timer kc8gw-v6-backup.timer >/dev/null
systemctl restart "$MON" "$WEB"
systemctl restart kc8gw-v6-index.timer kc8gw-v6-backup.timer
systemctl reload nginx
sleep 3

if "$TARGET/scripts/healthcheck.sh"; then
    printf '%s\n' "$SAFE" > "$TARGET/ROLLBACK_PATH"
    # Retired generic v5 timers can duplicate work; disable only after V6 is verified.
    for t in kc8gw-v5-backup.timer kc8gw-v5-index.timer; do systemctl disable --now "$t" 2>/dev/null || true; done
    echo 'V6.1 rebuilt interface update successful.'
    echo 'Open: http://100.120.203.11:8110/'
    echo "Rollback snapshot: $SAFE"
    exit 0
fi

echo 'ERROR: V6 health check failed. Restoring previous V6.'
systemctl stop "$WEB" "$MON" kc8gw-v6-index.timer kc8gw-v6-backup.timer 2>/dev/null || true
rm -rf "$TARGET"
[[ -d "$SAFE/current-v6" ]] && cp -a "$SAFE/current-v6" "$TARGET"
for f in "$SAFE/systemd"/*; do [[ -e "$f" ]] && cp -a "$f" /etc/systemd/system/; done
[[ -e "$SAFE/nginx/kc8gw-operations-v6" ]] && cp -a "$SAFE/nginx/kc8gw-operations-v6" "$NG_AV"
systemctl daemon-reload
nginx -t || true
systemctl restart "$WEB" "$MON" 2>/dev/null || true
systemctl reload nginx 2>/dev/null || true
exit 1
