# KC8GW Operations Center V6.1 Rebuilt UI

This package repairs the V6 workspace architecture while preserving the validated backend, monitor, storage, SQLite, audio archive, backups, authentication, Nginx and port 8110.

Key fix: Production and Hardening no longer inherit the Operations page incorrectly. A shared `base.html` shell now owns the header/navigation while each workspace supplies its own page body.

- Operations: live dispatch/operator console
- Production: unattended-operation readiness and promotion checklist
- Hardening: 24-hour soak and engineering validation

Install: `sudo bash install-v6-rebuilt.sh`
Rollback is automatic if the on-Pi health check fails.
