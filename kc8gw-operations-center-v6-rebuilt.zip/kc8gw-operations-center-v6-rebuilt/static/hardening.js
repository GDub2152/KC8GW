const $h=id=>document.getElementById(id);
async function hApi(path,opt={}){const r=await fetch(path,{headers:{"Content-Type":"application/json"},...opt});const d=await r.json();if(!r.ok)throw new Error(d.message||'Request failed');return d;}
function fmt(s){s=Number(s||0);const h=Math.floor(s/3600),m=Math.floor((s%3600)/60);return `${h}h ${m}m`;}
function checkRow(name,state,detail=''){const cls=state==='PASS'?'pass':state==='FAIL'?'fail':'warn';return `<div class="readiness-row ${cls}"><i></i><div><strong>${name}</strong><span>${detail}</span></div><b>${state}</b></div>`;}
async function loadHard(){
  try{
    const d=await hApi('/api/hardening'),h=d.hardening,diag=d.diagnostics||{};
    $h('hardReady').textContent=h.ready?'HARDENED':(h.soak_started?'SOAKING':'NOT STARTED');
    $h('hardReady').className='giant-state '+(h.ready?'ok':h.blockers.length?'attention':'soaking');
    $h('hardSoak').textContent=h.soak_started?fmt(h.soak_seconds):'0h 0m';$h('hardBlockers').textContent=h.blockers.length;$h('hardWarnings').textContent=h.warnings.length;
    $h('hardMonitor').textContent=diag.monitor_fresh?'PASS':'FAIL';$h('hardNode').textContent=diag.node_ok?'PASS':'FAIL';
    const pct=Math.min(100,Math.round((Number(h.soak_seconds||0)/Math.max(Number(h.soak_target_seconds||86400),1))*100));$h('soakProgress').style.width=`${pct}%`;
    const rows=(diag.checks||[]).map(c=>checkRow(c.label,c.ok?'PASS':(c.severity==='critical'?'FAIL':'CHECK'),c.detail));
    rows.push(checkRow('24-hour soak',h.soak_complete?'PASS':(h.soak_started?'IN PROGRESS':'NOT STARTED'),h.soak_started?`${fmt(h.soak_seconds)} elapsed`:'Start the soak when ready.'));
    $h('hardChecks').innerHTML=rows.join('');
    $h('hardMessage').textContent=h.ready?'Hardening complete with no current blockers. Production promotion is eligible.':(h.blockers.length?`Resolve blockers: ${h.blockers.join('; ')}`:(h.soak_started?'Continue normal station use until the 24-hour soak completes.':'Start the 24-hour soak after normal operation is verified.'));
  }catch(e){$h('hardMessage').textContent='ERROR: '+e.message;}
}
$h('startSoak')?.addEventListener('click',async()=>{if(!confirm('Start or restart the 24-hour hardening soak?'))return;const d=await hApi('/api/hardening/start',{method:'POST',body:'{}'});$h('hardMessage').textContent=d.message;loadHard();});
$h('resetSoak')?.addEventListener('click',async()=>{if(!confirm('Reset the hardening soak timer?'))return;const d=await hApi('/api/hardening/reset',{method:'POST',body:'{}'});$h('hardMessage').textContent=d.message;loadHard();});
loadHard();setInterval(loadHard,15000);
