const $p=id=>document.getElementById(id);
async function pApi(path,opt={}){const r=await fetch(path,{headers:{"Content-Type":"application/json"},...opt});const d=await r.json();if(!r.ok)throw new Error(d.message||"Request failed");return d;}
function readinessRow(name,state,detail=''){
  const cls=state==='PASS'?'pass':state==='FAIL'?'fail':'warn';
  return `<div class="readiness-row ${cls}"><i></i><div><strong>${name}</strong><span>${detail}</span></div><b>${state}</b></div>`;
}
function scoreFor(diag){
  const checks=diag.checks||[]; if(!checks.length)return 0;
  const weights=checks.map(c=>c.severity==='critical'?2:1); let earned=0,total=0;
  checks.forEach((c,i)=>{total+=weights[i]; if(c.ok)earned+=weights[i];});
  return Math.round((earned/Math.max(total,1))*100);
}
async function loadProduction(){
  try{
    const d=await pApi('/api/production'),diag=d.diagnostics||{},score=scoreFor(diag);
    $p('prodReady').textContent=d.ready?'READY':'ATTENTION';
    $p('prodReady').className='giant-state '+(d.ready?'ok':'attention');
    $p('prodCritical').textContent=d.critical.length;$p('prodWarnings').textContent=d.warnings.length;
    $p('prodScoreValue').textContent=`${score}%`;$p('prodScore').style.setProperty('--score',score);
    $p('prodChecked').textContent=new Date().toLocaleTimeString();
    const on=!!d.production.public_status_enabled;$p('prodPublic').textContent=on?'ON':'OFF';
    $p('togglePublic').textContent=on?'DISABLE PUBLIC STATUS':'ENABLE PUBLIC STATUS';$p('togglePublic').dataset.enabled=on?'1':'0';
    const rows=(diag.checks||[]).map(c=>readinessRow(c.label,c.ok?'PASS':(c.severity==='critical'?'FAIL':'CHECK'),c.detail));
    $p('prodChecklist').innerHTML=rows.join('')||readinessRow('Diagnostics','CHECK','No diagnostic rows returned.');
    $p('prodMessage').textContent=d.ready?'No critical blockers detected. Complete Hardening soak before final promotion.':(d.critical.length?`Critical blockers: ${d.critical.map(x=>x.title||x.label||x.key).join(', ')}`:'Warnings remain; review checklist.');
  }catch(e){$p('prodMessage').textContent='ERROR: '+e.message;}
}
$p('runSelfTest')?.addEventListener('click',loadProduction);
$p('togglePublic')?.addEventListener('click',async()=>{const enabled=$p('togglePublic').dataset.enabled!=='1';if(!confirm(`${enabled?'Enable':'Disable'} read-only public station status?`))return;try{const d=await pApi('/api/production/public-status',{method:'POST',body:JSON.stringify({enabled})});$p('prodMessage').textContent=d.message;loadProduction();}catch(e){$p('prodMessage').textContent='ERROR: '+e.message;}});
loadProduction();setInterval(loadProduction,60000);
